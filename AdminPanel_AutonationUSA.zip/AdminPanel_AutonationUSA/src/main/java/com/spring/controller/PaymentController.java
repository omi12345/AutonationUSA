package com.spring.controller;

import com.razorpay.Order;
import com.razorpay.RazorpayException;
import com.spring.entity.Part;
import com.spring.service.PartService;
import com.spring.service.RazorpayService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class PaymentController {

    @Autowired
    private RazorpayService razorpayService;

    @Autowired
    private PartService partService;
    @GetMapping("/customer/buy/{partId}")
    public String pay(@PathVariable Long partId, Model model) {
        try {
           // double amount = 400; // Replace with actual part price
        	 Part part = partService.getPartById(partId);
        	 double amount = part.getPrice() *100; // Assuming getPrice() returns an Integer
             
            Order order = razorpayService.createOrder(amount, "INR");
            model.addAttribute("orderId", order.get("id"));
            model.addAttribute("amount", amount);
            model.addAttribute("partName",part.getName());
        } catch (RazorpayException e) {
            e.printStackTrace();
            return "error";
        }
        return "paymentPage";
    }
}
