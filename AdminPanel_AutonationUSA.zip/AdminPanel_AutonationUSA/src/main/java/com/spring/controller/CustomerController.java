package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.spring.entity.Part;
import com.spring.service.PartService;

@Controller
public class CustomerController {

    @Autowired
    private PartService partService;

    @GetMapping("/customer/parts")
    public String listParts(Model model) {
        model.addAttribute("parts", partService.getAllParts());
        return "customerPartList";
    }

    @GetMapping("/customer/part/{id}")
    public String viewPart(@PathVariable Long id, Model model) {
        Part part = partService.getPartById(id);
        if (part == null) {
            return "redirect:/customer/parts";
        }
        model.addAttribute("part", part);
        return "customerPartDetail";
    }

//    @GetMapping("/customer/buy/{id}")
//    public String buyPart(@PathVariable Long id, Model model) {
//        Part part = partService.getPartById(id);
//        if (part == null) {
//            return "redirect:/customer/parts";
//        }
//        model.addAttribute("part", part);
//        return "paymentPage";
//    }
//    @PostMapping("/customer/processPayment")
//    public String processPayment(@RequestParam Long partId, @RequestParam String name,
//                                 @RequestParam String cardNumber, @RequestParam String expiryDate,
//                                 @RequestParam int cvv, Model model) {
//        // Logic to process payment
//        // If payment is successful, reduce stock of the part
//        Part part = partService.getPartById(partId);
//        if (part != null && part.getStock() > 0) {
//            part.setStock(part.getStock() - 1);
//            partService.savePart(part);
//            model.addAttribute("message", "Payment successful. Thank you for your purchase!");
//        } else {
//            model.addAttribute("message", "Payment failed or part out of stock.");
//        }
//        return "paymentResult";
//    }

}