package com.spring.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.spring.entity.Part;
import com.spring.service.PartService;

@Controller
public class PartController {

    @Autowired
    private PartService partService;

    @GetMapping("/parts")
    public String listParts(Model model) {
        model.addAttribute("parts", partService.getAllParts());
        return "partList";
    }

    @GetMapping("/new")
    public String createPartForm(Model model) {
        model.addAttribute("part", new Part());
        return "partForm";
    }

    @PostMapping("/save")
    public String savePart(@ModelAttribute("part") Part part) {
        partService.savePart(part);
        return "redirect:/parts";
    }

    @GetMapping("/edit/{id}")
    public String editPartForm(@PathVariable Long id, Model model) {
        model.addAttribute("part", partService.getPartById(id));
        return "partForm";
    }

    @GetMapping("/delete/{id}")
    public String deletePart(@PathVariable Long id) {
        partService.deletePart(id);
        return "redirect:/parts";
    }
}
