package com.spring.service;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Order;

@Service
public class RazorpayService {

    private String keyId="rzp_test_rlk3uG0U1TNrbw";

    private String keySecret="FqBK20DrVaukaIFpCQMUaxNb";

    public Order createOrder(double amount, String currency) throws RazorpayException {
        RazorpayClient razorpayClient = new RazorpayClient(keyId, keySecret);

        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", amount); // amount in the smallest currency unit
        orderRequest.put("currency", currency);
        orderRequest.put("receipt", "order_rcptid_11");

        return razorpayClient.orders.create(orderRequest);
    }
}
